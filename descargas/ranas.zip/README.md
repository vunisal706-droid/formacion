# 🐸 Capitulin y las Ranas - Llevadas

Aplicación educativa para aprender **sumas y restas con llevada** de forma visual e interactiva.

## 📋 Características

### Menú Principal Estilo Capitulin
- Diseño con colores institucionales del CEIP Capitulaciones de Santa Fe
- Logo animado con efecto de brillo
- Dos opciones grandes y claras:
  - **Sumas con Llevada** (verde)
  - **Restas con Llevada** (rojo)

### Modo Suma con Llevada
1. El niño suma las unidades (ej: 7 + 8 = 15)
2. Escribe el resultado completo: **15**
3. El 5 queda en unidades, el 1 aparece en un círculo abajo
4. **Toca la rana 🐸** para que salte y lleve el 1 arriba
5. El círculo de arriba **parpadea** cuando aparece el número
6. Ahora suma las decenas incluyendo la llevada

### Modo Resta con Llevada
1. El niño ve que no puede restar (ej: 2 - 8)
2. **Toca la rana 🐸** para "pedir prestado"
3. Aparece **-1** en el círculo de arriba (de las decenas)
4. Aparece **+1** en el círculo de abajo (para las unidades)
5. Las unidades cambian visualmente: 2 → **12** (en amarillo)
6. Las decenas se reducen: 4 → **3** (en verde)
7. Ahora puede restar: 12 - 8 = 4
8. Luego resta las decenas: 3 - 1 = 2

## 🎨 Diseño Visual

- **Menú**: Gradiente verde institucional, logo circular con rana
- **Sumas**: Tonos verdes con feedback positivo
- **Restas**: Tonos rojizos/rosados para diferenciar
- **Animaciones**: Parpadeo llamativo cuando aparecen los números
- **Teclado numérico**: Integrado en pantalla con colores acordes
- **Feedback**: Mensajes claros y felicitaciones al completar

## 📱 Funcionalidades

✅ **Navegación fluida** entre menú y modos  
✅ **Botón "Volver al Menú"** en cada modo  
✅ **Teclado numérico** para facilitar la entrada  
✅ **Validación en tiempo real** de respuestas  
✅ **Feedback visual** (verde=correcto, rojo=error)  
✅ **Animaciones** en los círculos de llevada/préstamo  
✅ **Botón "Nueva Suma/Resta"** al terminar  
✅ **Felicitaciones** al completar correctamente  
✅ **PWA** (puede instalarse como app)  

## 📂 Archivos

- `index.html` - Estructura completa con menú y ambos modos
- `style-menu.css` - Estilos del menú y las operaciones
- `app-principal.js` - Lógica de navegación, sumas y restas
- `manifest.json` - Para convertir en PWA

## 🎯 Uso en el Aula

**Para Sumas:**
- Los niños practican la mecánica de "llevar" el número
- Visualizan cómo la unidad "salta" a la columna de las decenas
- Aprenden el concepto de que 15 = 1 decena + 5 unidades

**Para Restas:**
- Los niños entienden el "pedir prestado"
- Ven cómo 1 decena = 10 unidades
- Practican la transformación visual del número

## 🏫 CEIP Capitulaciones de Santa Fe

Aplicación desarrollada para facilitar el aprendizaje de operaciones con llevada de forma lúdica y visual.

---

**Desarrollado por:** Víctor  
**Escuela:** CEIP Capitulaciones de Santa Fe, Granada
