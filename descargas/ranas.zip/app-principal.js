// ===================================
// NAVEGACIÓN ENTRE PANTALLAS
// ===================================

let modoActual = null;

function iniciarModo(modo) {
    modoActual = modo;
    document.getElementById('menu-principal').classList.remove('activa');
    
    if (modo === 'suma') {
        document.getElementById('pantalla-suma').classList.add('activa');
        iniciarSuma();
    } else if (modo === 'resta') {
        document.getElementById('pantalla-resta').classList.add('activa');
        iniciarResta();
    }
}

function volverMenu() {
    document.getElementById('pantalla-suma').classList.remove('activa');
    document.getElementById('pantalla-resta').classList.remove('activa');
    document.getElementById('menu-principal').classList.add('activa');
    modoActual = null;
}

// ===================================
// MÓDULO DE SUMAS
// ===================================

const Suma = {
    num1: 0,
    num2: 0,
    resultadoCorrecto: {},
    estado: 'unidades',
    
    generarProblema() {
        let u1, u2;
        do {
            u1 = Math.floor(Math.random() * 9) + 1;
            u2 = Math.floor(Math.random() * 9) + 1;
        } while (u1 + u2 < 10);

        const d1 = Math.floor(Math.random() * 9) + 1;
        const d2 = Math.floor(Math.random() * 9) + 1;

        this.num1 = d1 * 10 + u1;
        this.num2 = d2 * 10 + u2;

        const sumaTotal = this.num1 + this.num2;
        this.resultadoCorrecto = {
            U: (u1 + u2) % 10,
            L: Math.floor((u1 + u2) / 10),
            D: (d1 + d2 + Math.floor((u1 + u2) / 10)) % 10,
            C: Math.floor((d1 + d2 + Math.floor((u1 + u2) / 10)) / 10)
        };
        
        document.getElementById('suma-d1').textContent = d1;
        document.getElementById('suma-d2').textContent = d2;
        document.getElementById('suma-u1').textContent = u1;
        document.getElementById('suma-u2').textContent = u2;
    },
    
    resetUI() {
        this.estado = 'unidades';
        document.getElementById('suma-rU').value = '';
        document.getElementById('suma-rD').value = '';
        document.getElementById('suma-rC').value = '';
        document.getElementById('suma-llevada-arriba').textContent = '';
        document.getElementById('suma-llevada-abajo').textContent = '';
        
        document.getElementById('suma-llevada-arriba').classList.remove('parpadeo-llevada');
        
        document.getElementById('suma-rU').readOnly = false;
        document.getElementById('suma-rD').readOnly = true;
        document.getElementById('suma-rC').readOnly = true;
        document.getElementById('suma-rU').classList.remove('correcto', 'error');
        document.getElementById('suma-rD').classList.remove('correcto', 'error');
        document.getElementById('suma-rC').classList.remove('correcto', 'error');
        
        document.getElementById('suma-boton-rana').disabled = true;
        document.getElementById('suma-boton-rana').classList.remove('activo');
        document.getElementById('suma-boton-nueva').classList.add('oculto');
    },
    
    manejarInputUnidades(inputVal) {
        if (inputVal.length === 2) {
            const inputNum = parseInt(inputVal);
            const sumaU = parseInt(document.getElementById('suma-u1').textContent) + 
                         parseInt(document.getElementById('suma-u2').textContent);

            if (inputNum === sumaU) {
                document.getElementById('suma-rU').classList.add('correcto');
                document.getElementById('suma-rU').readOnly = true;
                
                const llevada = Math.floor(inputNum / 10);
                const unidadFinal = inputNum % 10;
                document.getElementById('suma-rU').value = unidadFinal;
                document.getElementById('suma-llevada-abajo').textContent = llevada;
                
                this.estado = 'llevada';
                document.getElementById('suma-boton-rana').disabled = false;
                document.getElementById('suma-boton-rana').classList.add('activo');
                this.mostrarFeedback("¡Genial! Mueve la llevada tocando la rana.");
            } else {
                document.getElementById('suma-rU').classList.add('error');
                this.mostrarFeedback("Esa suma de unidades no es correcta. Intenta de nuevo.");
                setTimeout(() => {
                    document.getElementById('suma-rU').classList.remove('error');
                    document.getElementById('suma-rU').value = '';
                }, 1500);
            }
        }
    },
    
    moverLlevada() {
        if (this.estado === 'llevada') {
            const llevada = document.getElementById('suma-llevada-abajo').textContent;
            document.getElementById('suma-boton-rana').disabled = true;
            document.getElementById('suma-boton-rana').classList.remove('activo');
            document.getElementById('suma-llevada-abajo').textContent = '';

            setTimeout(() => {
                const circuloArriba = document.getElementById('suma-llevada-arriba');
                circuloArriba.textContent = llevada;
                circuloArriba.classList.add('parpadeo-llevada');
                
                setTimeout(() => {
                    circuloArriba.classList.remove('parpadeo-llevada');
                }, 1800);
                
                this.estado = 'decenas';
                document.getElementById('suma-rD').readOnly = false;
                this.mostrarFeedback("¡Perfecto! Ahora suma la columna de las decenas.");
            }, 300);
        }
    },
    
    manejarInputDecenas(inputVal) {
        if (this.estado === 'decenas') {
            const totalDecenas = this.resultadoCorrecto.D + this.resultadoCorrecto.C * 10;
            const digitosEsperados = totalDecenas >= 10 ? 2 : 1;
            
            if (inputVal.length === digitosEsperados) {
                const inputNum = parseInt(inputVal);

                if (inputNum === totalDecenas) {
                    document.getElementById('suma-rD').classList.add('correcto');
                    document.getElementById('suma-rD').readOnly = true;

                    const decenasFinal = totalDecenas % 10;
                    const centenasFinal = Math.floor(totalDecenas / 10);
                    
                    document.getElementById('suma-rD').value = decenasFinal;
                    if (centenasFinal > 0) {
                        document.getElementById('suma-rC').value = centenasFinal;
                        document.getElementById('suma-rC').classList.add('correcto');
                    }

                    this.mostrarFeedback("🎉 ¡FELICIDADES! ¡Lo has hecho genial! 🎉");
                    document.getElementById('suma-boton-nueva').classList.remove('oculto');
                } else {
                    document.getElementById('suma-rD').classList.add('error');
                    this.mostrarFeedback("Esa suma de decenas no es correcta. Intenta de nuevo.");
                    setTimeout(() => {
                        document.getElementById('suma-rD').classList.remove('error');
                        document.getElementById('suma-rD').value = '';
                    }, 1500);
                }
            }
        }
    },
    
    mostrarFeedback(mensaje) {
        document.getElementById('suma-mensaje-feedback').textContent = mensaje;
    }
};

// ===================================
// MÓDULO DE RESTAS
// ===================================

const Resta = {
    num1: 0,
    num2: 0,
    resultadoCorrecto: {},
    estado: 'inicial',
    u1Original: 0,
    d1Original: 0,
    
    generarProblema() {
        let u1, u2, d1, d2;
        
        do {
            u1 = Math.floor(Math.random() * 9) + 1;
            u2 = Math.floor(Math.random() * 9) + 1;
        } while (u1 >= u2);

        do {
            d1 = Math.floor(Math.random() * 9) + 1;
            d2 = Math.floor(Math.random() * 9) + 1;
        } while (d1 <= d2);

        this.num1 = d1 * 10 + u1;
        this.num2 = d2 * 10 + u2;
        this.u1Original = u1;
        this.d1Original = d1;

        const restaTotal = this.num1 - this.num2;
        this.resultadoCorrecto = {
            U: (u1 + 10 - u2),
            D: (d1 - 1 - d2),
            total: restaTotal
        };
        
        document.getElementById('resta-d1').textContent = d1;
        document.getElementById('resta-d2').textContent = d2;
        document.getElementById('resta-u1').textContent = u1;
        document.getElementById('resta-u2').textContent = u2;
    },
    
    resetUI() {
        this.estado = 'inicial';
        
        document.getElementById('resta-rU').value = '';
        document.getElementById('resta-rD').value = '';
        document.getElementById('resta-rC').value = '';
        document.getElementById('resta-prestamo-arriba').textContent = '';
        document.getElementById('resta-prestamo-abajo').textContent = '';

        document.getElementById('resta-prestamo-arriba').classList.remove('parpadeo-prestamo');
        document.getElementById('resta-prestamo-abajo').classList.remove('parpadeo-prestamo');

        document.getElementById('resta-rU').readOnly = true;
        document.getElementById('resta-rD').readOnly = true;
        document.getElementById('resta-rC').readOnly = true;
        document.getElementById('resta-rU').classList.remove('correcto', 'error');
        document.getElementById('resta-rD').classList.remove('correcto', 'error');
        document.getElementById('resta-rC').classList.remove('correcto', 'error');

        document.getElementById('resta-boton-rana').disabled = false;
        document.getElementById('resta-boton-rana').classList.add('activo');
        document.getElementById('resta-boton-nueva').classList.add('oculto');
        
        // Restaurar valores originales
        document.getElementById('resta-u1').textContent = this.u1Original;
        document.getElementById('resta-d1').textContent = this.d1Original;
        document.getElementById('resta-u1').style.backgroundColor = '';
        document.getElementById('resta-d1').style.backgroundColor = '';
    },
    
    pedirPrestamo() {
        if (this.estado === 'inicial') {
            this.estado = 'necesita-prestamo';
            
            document.getElementById('resta-boton-rana').disabled = true;
            document.getElementById('resta-boton-rana').classList.remove('activo');
            
            const circuloArriba = document.getElementById('resta-prestamo-arriba');
            circuloArriba.textContent = '-1';
            circuloArriba.classList.add('parpadeo-prestamo');
            
            setTimeout(() => {
                circuloArriba.classList.remove('parpadeo-prestamo');
                
                setTimeout(() => {
                    const circuloAbajo = document.getElementById('resta-prestamo-abajo');
                    circuloAbajo.textContent = '+1';
                    circuloAbajo.classList.add('parpadeo-prestamo');
                    
                    const u1Actual = parseInt(document.getElementById('resta-u1').textContent);
                    document.getElementById('resta-u1').textContent = u1Actual + 10;
                    document.getElementById('resta-u1').style.backgroundColor = '#FFD54F';
                    
                    const d1Actual = parseInt(document.getElementById('resta-d1').textContent);
                    document.getElementById('resta-d1').textContent = d1Actual - 1;
                    document.getElementById('resta-d1').style.backgroundColor = '#81C784';
                    
                    setTimeout(() => {
                        circuloAbajo.classList.remove('parpadeo-prestamo');
                    }, 1800);
                    
                    this.estado = 'unidades';
                    document.getElementById('resta-rU').readOnly = false;
                    this.mostrarFeedback("¡Genial! Ahora puedes restar las unidades.");
                }, 500);
            }, 1800);
        }
    },
    
    manejarInputUnidades(inputVal) {
        if (this.estado === 'unidades' && inputVal.length >= 1) {
            const inputNum = parseInt(inputVal);
            const u1Actual = parseInt(document.getElementById('resta-u1').textContent);
            const u2 = parseInt(document.getElementById('resta-u2').textContent);
            const resultadoEsperado = u1Actual - u2;

            if (inputNum === resultadoEsperado) {
                document.getElementById('resta-rU').classList.add('correcto');
                document.getElementById('resta-rU').readOnly = true;
                document.getElementById('resta-prestamo-abajo').textContent = '';
                
                this.estado = 'decenas';
                document.getElementById('resta-rD').readOnly = false;
                this.mostrarFeedback("¡Perfecto! Ahora resta las decenas.");
            } else if (inputVal.length === resultadoEsperado.toString().length) {
                document.getElementById('resta-rU').classList.add('error');
                this.mostrarFeedback("Esa resta no es correcta. Intenta de nuevo.");
                setTimeout(() => {
                    document.getElementById('resta-rU').classList.remove('error');
                    document.getElementById('resta-rU').value = '';
                }, 1500);
            }
        }
    },
    
    manejarInputDecenas(inputVal) {
        if (this.estado === 'decenas' && inputVal.length === 1) {
            const inputNum = parseInt(inputVal);
            const d1Actual = parseInt(document.getElementById('resta-d1').textContent);
            const d2 = parseInt(document.getElementById('resta-d2').textContent);
            const resultadoEsperado = d1Actual - d2;

            if (inputNum === resultadoEsperado) {
                document.getElementById('resta-rD').classList.add('correcto');
                document.getElementById('resta-rD').readOnly = true;
                document.getElementById('resta-prestamo-arriba').textContent = '';
                document.getElementById('resta-u1').style.backgroundColor = '';
                document.getElementById('resta-d1').style.backgroundColor = '';
                
                this.mostrarFeedback("🎉 ¡FELICIDADES! ¡Lo has hecho genial! 🎉");
                document.getElementById('resta-boton-nueva').classList.remove('oculto');
            } else {
                document.getElementById('resta-rD').classList.add('error');
                this.mostrarFeedback("Esa resta de decenas no es correcta. Intenta de nuevo.");
                setTimeout(() => {
                    document.getElementById('resta-rD').classList.remove('error');
                    document.getElementById('resta-rD').value = '';
                }, 1500);
            }
        }
    },
    
    mostrarFeedback(mensaje) {
        document.getElementById('resta-mensaje-feedback').textContent = mensaje;
    }
};

// ===================================
// INICIALIZACIÓN Y EVENT LISTENERS
// ===================================

function iniciarSuma() {
    Suma.resetUI();
    Suma.generarProblema();
    Suma.mostrarFeedback("Suma las unidades y escribe la respuesta (ej: 14).");
    crearTecladoSuma();
}

function iniciarResta() {
    Resta.resetUI();
    Resta.generarProblema();
    Resta.mostrarFeedback("¡Toca la rana 🐸 para pedir prestado y poder restar!");
    crearTecladoResta();
}

// Event Listeners - SUMA
document.getElementById('suma-rU').addEventListener('input', (e) => {
    let inputVal = e.target.value;
    if (inputVal.length > 2) {
        e.target.value = inputVal.slice(0, 2);
        inputVal = e.target.value;
    }
    Suma.manejarInputUnidades(inputVal);
});

document.getElementById('suma-rD').addEventListener('input', (e) => {
    let inputVal = e.target.value;
    if (inputVal.length > 2) {
        e.target.value = inputVal.slice(0, 2);
        inputVal = e.target.value;
    }
    Suma.manejarInputDecenas(inputVal);
});

document.getElementById('suma-boton-rana').addEventListener('click', () => Suma.moverLlevada());
document.getElementById('suma-boton-nueva').addEventListener('click', iniciarSuma);

// Event Listeners - RESTA
document.getElementById('resta-rU').addEventListener('input', (e) => {
    let inputVal = e.target.value;
    if (inputVal.length > 2) {
        e.target.value = inputVal.slice(0, 2);
        inputVal = e.target.value;
    }
    Resta.manejarInputUnidades(inputVal);
});

document.getElementById('resta-rD').addEventListener('input', (e) => {
    let inputVal = e.target.value;
    if (inputVal.length > 1) {
        e.target.value = inputVal.slice(0, 1);
        inputVal = e.target.value;
    }
    Resta.manejarInputDecenas(inputVal);
});

document.getElementById('resta-boton-rana').addEventListener('click', () => Resta.pedirPrestamo());
document.getElementById('resta-boton-nueva').addEventListener('click', iniciarResta);

// Teclados numéricos
function crearTecladoSuma() {
    const teclado = document.getElementById('suma-teclado-numerico');
    teclado.innerHTML = '';
    for (let i = 9; i >= 0; i--) {
        const boton = document.createElement('button');
        boton.textContent = i;
        boton.classList.add('teclado-boton');
        boton.addEventListener('click', () => {
            if (Suma.estado === 'unidades' && !document.getElementById('suma-rU').readOnly) {
                document.getElementById('suma-rU').value += i;
                document.getElementById('suma-rU').dispatchEvent(new Event('input'));
            } else if (Suma.estado === 'decenas' && !document.getElementById('suma-rD').readOnly) {
                document.getElementById('suma-rD').value += i;
                document.getElementById('suma-rD').dispatchEvent(new Event('input'));
            }
        });
        teclado.appendChild(boton);
    }
}

function crearTecladoResta() {
    const teclado = document.getElementById('resta-teclado-numerico');
    teclado.innerHTML = '';
    for (let i = 9; i >= 0; i--) {
        const boton = document.createElement('button');
        boton.textContent = i;
        boton.classList.add('teclado-boton');
        boton.addEventListener('click', () => {
            if (Resta.estado === 'unidades' && !document.getElementById('resta-rU').readOnly) {
                document.getElementById('resta-rU').value += i;
                document.getElementById('resta-rU').dispatchEvent(new Event('input'));
            } else if (Resta.estado === 'decenas' && !document.getElementById('resta-rD').readOnly) {
                document.getElementById('resta-rD').value += i;
                document.getElementById('resta-rD').dispatchEvent(new Event('input'));
            }
        });
        teclado.appendChild(boton);
    }
}
